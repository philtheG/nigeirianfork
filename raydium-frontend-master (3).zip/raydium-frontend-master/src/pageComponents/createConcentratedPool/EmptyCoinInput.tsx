export default function EmptyCoinInput() {
  return (
    <div className="flex mb-4 px-5 h-[91px] mobile:h-[75px] items-center text-secondary-title opacity-50 bg-dark-blue rounded-xl">
      Select Token
    </div>
  )
}

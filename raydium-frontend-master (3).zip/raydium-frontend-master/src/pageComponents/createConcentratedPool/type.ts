export enum Range {
  Low = 'priceLower',
  Upper = 'priceUpper'
}

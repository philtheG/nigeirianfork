export type ChartPoint = {
  x: number
  y: number
}
